#define N 1
#define D 2
#define ERR 0

